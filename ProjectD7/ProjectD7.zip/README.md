## Project D: Twitter Data Analysis
* Group D7
* Task 1 : Cindy Ho
* Task 2 : Gurvinder Mann
* Task 3 : Daniel Martinez Garzon
